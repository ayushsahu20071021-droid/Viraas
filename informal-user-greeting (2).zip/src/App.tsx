import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import CategoryPage from './pages/CategoryPage';
import ProductPage from './pages/ProductPage';
import OccasionsPage from './pages/OccasionsPage';
import TryOnPage from './pages/TryOnPage';
import JournalPage from './pages/JournalPage';
import SearchPage from './pages/SearchPage';
import SavedPage from './pages/SavedPage';
import LookPage from './pages/LookPage';
import {
  AboutPage,
  ContactPage,
  FAQPage,
  PrivacyPage,
  TermsPage,
  AffiliateDisclosurePage,
  AITryOnPrivacyPage,
  CoupleEditPage,
  TrendingPage,
} from './pages/StaticPages';

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-[#F6F0E6]" style={{ fontFamily: "'DM Sans', sans-serif" }}>
        <Header />
        <main>
          <Routes>
            <Route path="/" element={<Home />} />

            {/* Category pages */}
            <Route
              path="/women"
              element={
                <CategoryPage
                  gender="women"
                  title="For Her"
                  subtitle="Indian silhouettes, styled for now."
                  heroImage="/images/hero-women.jpg"
                />
              }
            />
            <Route
              path="/men"
              element={
                <CategoryPage
                  gender="men"
                  title="For Him"
                  subtitle="Modern festive tailoring, rooted in tradition."
                  heroImage="/images/hero-men.jpg"
                />
              }
            />
            <Route
              path="/accessories"
              element={
                <CategoryPage
                  gender="accessories"
                  title="Accessories"
                  subtitle="Complete the look — jewellery, bags, footwear."
                  heroImage="/images/hero-women.jpg"
                />
              }
            />

            {/* Occasions */}
            <Route path="/occasions" element={<OccasionsPage />} />
            <Route path="/occasions/:id" element={<OccasionsPage />} />

            {/* Product */}
            <Route path="/product/:id" element={<ProductPage />} />

            {/* Looks */}
            <Route path="/look/:id" element={<LookPage />} />

            {/* Try On */}
            <Route path="/try-on" element={<TryOnPage />} />

            {/* Journal */}
            <Route path="/journal" element={<JournalPage />} />
            <Route path="/journal/:slug" element={<JournalPage />} />

            {/* Search */}
            <Route path="/search" element={<SearchPage />} />

            {/* Saved */}
            <Route path="/saved" element={<SavedPage />} />

            {/* Couple & Trending */}
            <Route path="/couple" element={<CoupleEditPage />} />
            <Route path="/trending" element={<TrendingPage />} />

            {/* Static */}
            <Route path="/about" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/faq" element={<FAQPage />} />
            <Route path="/privacy" element={<PrivacyPage />} />
            <Route path="/terms" element={<TermsPage />} />
            <Route path="/affiliate-disclosure" element={<AffiliateDisclosurePage />} />
            <Route path="/ai-tryon-privacy" element={<AITryOnPrivacyPage />} />

            {/* 404 */}
            <Route
              path="*"
              element={
                <div className="min-h-screen flex items-center justify-center bg-[#F6F0E6] pt-20">
                  <div className="text-center">
                    <p className="font-playfair text-6xl text-[#E9E1D4] mb-4">404</p>
                    <h1 className="font-playfair text-2xl text-[#171918] mb-4">Page not found</h1>
                    <a href="/" className="text-[#103C35] font-semibold hover:underline">Go home</a>
                  </div>
                </div>
              }
            />
          </Routes>
        </main>
        <Footer />
      </div>
    </BrowserRouter>
  );
}
