// Analytics utility — replace GA_ID and META_PIXEL_ID with real env values

/* eslint-disable @typescript-eslint/no-explicit-any */
declare const __DEV__: boolean;

type EventName =
  | 'view_product'
  | 'click_try_on'
  | 'try_on_success'
  | 'try_on_error'
  | 'save_look'
  | 'share_look'
  | 'affiliate_outbound_click'
  | 'whatsapp_click'
  | 'search'
  | 'filter_used';

interface EventParams {
  productId?: string;
  merchant?: string;
  category?: string;
  pageSource?: string;
  query?: string;
  filter?: string;
}

export const trackEvent = (name: EventName, params?: EventParams) => {
  if (typeof window === 'undefined') return;

  // Google Analytics 4
  if ((window as any).gtag) {
    (window as any).gtag('event', name, params || {});
  }

  // Meta Pixel
  if ((window as any).fbq) {
    (window as any).fbq('trackCustom', name, params || {});
  }
};

export const trackAffiliateClick = (productId: string, merchant: string, category: string) => {
  trackEvent('affiliate_outbound_click', { productId, merchant, category });
};

export const trackTryOn = (productId: string, success: boolean) => {
  trackEvent(success ? 'try_on_success' : 'try_on_error', { productId });
};
