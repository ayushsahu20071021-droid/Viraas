export interface Article {
  id: string;
  title: string;
  excerpt: string;
  category: string;
  readTime: string;
  date: string;
  image: string;
  tags: string[];
  slug: string;
}

export const articles: Article[] = [
  {
    id: 'art-001',
    title: 'Best Diwali Outfits for Gen Z in 2026',
    excerpt: 'From pre-draped sarees to festive co-ords — a curated Diwali edit for the 16–24 crowd.',
    category: 'Occasions',
    readTime: '4 min',
    date: '2026-01-10',
    image: '/images/occasion-diwali.jpg',
    tags: ['Diwali', 'Gen Z', 'Women'],
    slug: 'diwali-outfits-gen-z-2026',
  },
  {
    id: 'art-002',
    title: 'Modern Saree Looks for 2026',
    excerpt: 'Pre-draped, concept and minimal — the saree is having its most contemporary moment yet.',
    category: 'Style',
    readTime: '5 min',
    date: '2026-01-08',
    image: '/images/hero-women.jpg',
    tags: ['Saree', 'Modern', 'Women'],
    slug: 'modern-saree-looks-2026',
  },
  {
    id: 'art-003',
    title: 'Kurta + Jacket Combinations for Men',
    excerpt: 'The Nehru jacket formula — how to wear it for Diwali, weddings and everything in between.',
    category: 'Men',
    readTime: '4 min',
    date: '2026-01-05',
    image: '/images/hero-men.jpg',
    tags: ['Men', 'Kurta', 'Jacket'],
    slug: 'kurta-jacket-men-guide',
  },
  {
    id: 'art-004',
    title: 'Navratri Looks for College Students',
    excerpt: 'Vibrant, affordable and dance-floor-ready — Navratri dressing for the college crowd.',
    category: 'Occasions',
    readTime: '3 min',
    date: '2026-01-03',
    image: '/images/occasion-navratri.jpg',
    tags: ['Navratri', 'College', 'Budget'],
    slug: 'navratri-college-looks',
  },
  {
    id: 'art-005',
    title: 'Festive Looks Under ₹1,500',
    excerpt: 'A curated selection of festive outfits that prove great style does not require a big budget.',
    category: 'Budget',
    readTime: '5 min',
    date: '2025-12-28',
    image: '/images/hero-women.jpg',
    tags: ['Budget', 'Festive', 'Women'],
    slug: 'festive-looks-under-1500',
  },
  {
    id: 'art-006',
    title: 'The Chikankari Styling Guide',
    excerpt: 'How to wear chikankari in 2026 — from traditional suits to fusion silhouettes.',
    category: 'Style',
    readTime: '6 min',
    date: '2025-12-22',
    image: '/images/hero-women.jpg',
    tags: ['Chikankari', 'Style Guide', 'Women'],
    slug: 'chikankari-styling-guide',
  },
  {
    id: 'art-007',
    title: 'Modern Couple Festive Looks',
    excerpt: 'Coordinated, complementary or colour-story matched — festive dressing for two.',
    category: 'Couple',
    readTime: '4 min',
    date: '2025-12-18',
    image: '/images/couple-edit.jpg',
    tags: ['Couple', 'Festive', 'Diwali'],
    slug: 'modern-couple-festive-looks',
  },
  {
    id: 'art-008',
    title: "Men's Festive Style Guide 2026",
    excerpt: 'From ivory kurtas to emerald bandhgalas — the complete men\'s festive wardrobe breakdown.',
    category: 'Men',
    readTime: '6 min',
    date: '2025-12-15',
    image: '/images/hero-men.jpg',
    tags: ['Men', 'Festive', 'Style Guide'],
    slug: 'mens-festive-style-guide-2026',
  },
];
