export interface Occasion {
  id: string;
  title: string;
  subtitle: string;
  image: string;
  featured: boolean;
}

export const occasions: Occasion[] = [
  {
    id: 'diwali',
    title: 'Diwali',
    subtitle: 'Jewel tones & golden evenings',
    image: '/images/occasion-diwali.jpg',
    featured: true,
  },
  {
    id: 'navratri',
    title: 'Navratri',
    subtitle: 'Mirror, colour & movement',
    image: '/images/occasion-navratri.jpg',
    featured: true,
  },
  {
    id: 'wedding',
    title: 'Wedding',
    subtitle: 'Timeless & considered',
    image: '/images/occasion-wedding.jpg',
    featured: true,
  },
  {
    id: 'sangeet',
    title: 'Sangeet',
    subtitle: 'Statement looks for the dance',
    image: '/images/occasion-diwali.jpg',
    featured: true,
  },
  {
    id: 'reception',
    title: 'Reception',
    subtitle: 'Polished & evening-ready',
    image: '/images/occasion-wedding.jpg',
    featured: true,
  },
  {
    id: 'festive-party',
    title: 'Festive Party',
    subtitle: 'Contemporary & celebration-worthy',
    image: '/images/couple-edit.jpg',
    featured: true,
  },
  {
    id: 'mehendi',
    title: 'Mehendi',
    subtitle: 'Soft tones for a morning ceremony',
    image: '/images/hero-women.jpg',
    featured: false,
  },
  {
    id: 'haldi',
    title: 'Haldi',
    subtitle: 'Bright, light & playful',
    image: '/images/hero-women.jpg',
    featured: false,
  },
  {
    id: 'college-fest',
    title: 'College Fest',
    subtitle: 'Youthful, affordable, social-first',
    image: '/images/hero-women.jpg',
    featured: false,
  },
  {
    id: 'office-festive',
    title: 'Office Festive',
    subtitle: 'Polished ethnic for work celebrations',
    image: '/images/hero-women.jpg',
    featured: false,
  },
  {
    id: 'wedding-guest',
    title: 'Wedding Guest',
    subtitle: 'Curated looks for the shaadi season',
    image: '/images/occasion-wedding.jpg',
    featured: false,
  },
  {
    id: 'garba',
    title: 'Garba',
    subtitle: 'Dance-floor festive energy',
    image: '/images/occasion-navratri.jpg',
    featured: false,
  },
];

export const getFeaturedOccasions = () => occasions.filter(o => o.featured);
