import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { occasions } from '../data/occasions';
import { products } from '../data/products';
import { looks } from '../data/looks';
import ProductCard from '../components/ProductCard';
import TryOnModal from '../components/TryOnModal';
import { type Product } from '../data/products';

export default function OccasionsPage() {
  const { id } = useParams<{ id?: string }>();
  const [tryOnProduct, setTryOnProduct] = useState<Product | null>(null);

  if (id) {
    // Single occasion view
    const occasion = occasions.find(o => o.id === id);
    const occasionProducts = products.filter(p => p.occasion.includes(id));
    const occasionLooks = looks.filter(l => l.occasion === id);

    return (
      <>
        <div className="min-h-screen bg-[#F6F0E6] pt-16 lg:pt-20">
          {/* Hero */}
          <div className="relative py-20 lg:py-28 overflow-hidden">
            <div
              className="absolute inset-0 bg-cover bg-center"
              style={{ backgroundImage: `url(${occasion?.image || '/images/hero-women.jpg'})` }}
            />
            <div className="absolute inset-0 bg-gradient-to-b from-[#171918]/70 to-[#171918]/60" />
            <div className="relative z-10 max-w-screen-xl mx-auto px-4 sm:px-8 text-center">
              <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-4">Occasion Edit</p>
              <h1 className="font-playfair text-4xl lg:text-7xl text-white mb-4">{occasion?.title || id}</h1>
              <p className="text-[#AEB8A0] text-base max-w-md mx-auto">{occasion?.subtitle}</p>
            </div>
          </div>

          <div className="max-w-screen-xl mx-auto px-4 sm:px-8 py-16">
            {/* Curated Looks */}
            {occasionLooks.length > 0 && (
              <div className="mb-16">
                <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-3">Curated Looks</p>
                <h2 className="font-playfair text-2xl lg:text-3xl text-[#171918] mb-8">Complete Looks for {occasion?.title}</h2>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {occasionLooks.map(look => (
                    <Link
                      key={look.lookId}
                      to={`/look/${look.lookId}`}
                      className="group relative rounded-2xl overflow-hidden aspect-[3/4] bg-[#E9E1D4]"
                    >
                      <img src={look.heroImage} alt={look.title} className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#171918]/80 to-transparent" />
                      <div className="absolute bottom-0 p-5">
                        <h3 className="font-playfair text-xl text-white mb-1">{look.title}</h3>
                        <p className="text-[#AEB8A0] text-xs">{look.description}</p>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {/* Products */}
            <div>
              <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-3">Shop the Occasion</p>
              <h2 className="font-playfair text-2xl lg:text-3xl text-[#171918] mb-8">All {occasion?.title} Outfits</h2>
              {occasionProducts.length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                  {occasionProducts.map(p => (
                    <ProductCard key={p.id} product={p} onTryOn={setTryOnProduct} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-16">
                  <p className="font-playfair text-xl text-[#171918] mb-4">More looks coming soon.</p>
                  <Link to="/women" className="text-sm text-[#103C35] font-semibold hover:underline">Browse All Women</Link>
                </div>
              )}
            </div>
          </div>
        </div>
        {tryOnProduct && <TryOnModal product={tryOnProduct} onClose={() => setTryOnProduct(null)} />}
      </>
    );
  }

  // All occasions
  return (
    <div className="min-h-screen bg-[#F6F0E6] pt-16 lg:pt-20">
      <div className="max-w-screen-xl mx-auto px-4 sm:px-8 py-16">
        <div className="mb-12 text-center">
          <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-4">All Occasions</p>
          <h1 className="font-playfair text-4xl lg:text-6xl text-[#171918] mb-4">Dress for the Moment</h1>
          <p className="text-[#AEB8A0] max-w-md mx-auto">From Diwali to college fests — every occasion, fully styled.</p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {occasions.map(occasion => (
            <Link
              key={occasion.id}
              to={`/occasions/${occasion.id}`}
              className="group relative rounded-2xl overflow-hidden aspect-[3/4] bg-[#E9E1D4]"
            >
              <img
                src={occasion.image}
                alt={occasion.title}
                loading="lazy"
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#171918]/80 via-transparent to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-5">
                <h3 className="font-playfair text-xl text-white mb-1">{occasion.title}</h3>
                <p className="text-[#AEB8A0] text-xs flex items-center gap-1">{occasion.subtitle} <ArrowRight size={12} /></p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
