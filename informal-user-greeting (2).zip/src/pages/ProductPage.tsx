import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Heart, Sparkles, ShoppingBag, ArrowLeft, Share2, ExternalLink } from 'lucide-react';
import { getProductById, products } from '../data/products';
import { toggleSavedLook, isLookSaved } from '../utils/savedLooks';
import { trackAffiliateClick, trackEvent } from '../utils/analytics';
import TryOnModal from '../components/TryOnModal';
import ProductCard from '../components/ProductCard';
import { type Product } from '../data/products';

export default function ProductPage() {
  const { id } = useParams<{ id: string }>();
  const product = getProductById(id || '');
  const [tryOnOpen, setTryOnOpen] = useState(false);
  const [saved, setSaved] = useState(() => isLookSaved(id || ''));
  const [tryOnProduct, setTryOnProduct] = useState<Product | null>(null);
  const [imgError, setImgError] = useState(false);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F6F0E6] pt-20">
        <div className="text-center">
          <h1 className="font-playfair text-3xl text-[#171918] mb-4">Product not found</h1>
          <Link to="/women" className="text-[#103C35] font-semibold hover:underline">Browse Women</Link>
        </div>
      </div>
    );
  }

  const related = products
    .filter(p => p.id !== product.id && (p.category === product.category || p.occasion.some(o => product.occasion.includes(o))))
    .slice(0, 4);

  const accessories = products
    .filter(p => (p.category === 'accessories' || p.category === 'footwear') && p.id !== product.id)
    .slice(0, 4);

  const handleSave = () => {
    const isNowSaved = toggleSavedLook(product.id);
    setSaved(isNowSaved);
    if (isNowSaved) trackEvent('save_look', { productId: product.id });
  };

  const handleShop = () => {
    const url = product.affiliateUrl || product.merchantUrl;
    if (url && url !== '#') {
      trackAffiliateClick(product.id, product.merchant, product.category);
      window.open(url, '_blank', 'noopener,noreferrer');
    }
  };

  const handleShare = async () => {
    const shareData = {
      title: product.title,
      text: `Check out this look on VIRAAS — ${product.title}`,
      url: window.location.href,
    };
    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(window.location.href);
        alert('Link copied!');
      }
      trackEvent('share_look', { productId: product.id });
    } catch { /* cancelled */ }
  };

  const merchantLabel = product.merchant.charAt(0) + product.merchant.slice(1).toLowerCase();

  return (
    <>
      <div className="min-h-screen bg-[#F6F0E6] pt-16 lg:pt-20">
        {/* Breadcrumb */}
        <div className="max-w-screen-xl mx-auto px-4 sm:px-8 py-4">
          <Link
            to={`/${product.gender}`}
            className="inline-flex items-center gap-2 text-sm text-[#AEB8A0] hover:text-[#103C35] transition-colors"
          >
            <ArrowLeft size={16} /> Back
          </Link>
        </div>

        {/* Product */}
        <div className="max-w-screen-xl mx-auto px-4 sm:px-8 pb-16">
          <div className="grid lg:grid-cols-2 gap-10 lg:gap-16">
            {/* Image */}
            <div className="relative">
              <div className="aspect-[3/4] rounded-3xl overflow-hidden bg-[#E9E1D4]">
                <img
                  src={imgError ? '/images/hero-women.jpg' : product.imageUrl}
                  alt={product.title}
                  onError={() => setImgError(true)}
                  className="w-full h-full object-cover"
                />
              </div>
              <button
                onClick={handleSave}
                className={`absolute top-5 right-5 w-12 h-12 flex items-center justify-center rounded-full shadow-md transition-all ${
                  saved ? 'bg-[#D95E3F] text-white' : 'bg-white text-[#171918] hover:bg-[#D95E3F] hover:text-white'
                }`}
              >
                <Heart size={20} fill={saved ? 'currentColor' : 'none'} />
              </button>
            </div>

            {/* Info */}
            <div className="lg:pt-6">
              {/* Meta */}
              <div className="flex items-center gap-2 mb-4">
                <span className="text-xs font-semibold tracking-widest text-[#B7945A] uppercase">
                  {product.category.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </span>
                <span className="text-[#E9E1D4]">·</span>
                <span className="text-xs text-[#AEB8A0]">{merchantLabel}</span>
              </div>

              <h1 className="font-playfair text-3xl lg:text-4xl text-[#171918] mb-4 leading-tight">
                {product.title}
              </h1>

              {/* Price */}
              <div className="flex items-center gap-3 mb-6">
                <span className="text-3xl font-bold text-[#103C35]">
                  ₹{product.price.toLocaleString('en-IN')}
                </span>
                {product.mrp > product.price && (
                  <>
                    <span className="text-lg text-[#AEB8A0] line-through">₹{product.mrp.toLocaleString('en-IN')}</span>
                    <span className="px-2 py-1 bg-[#D95E3F] text-white text-xs font-semibold rounded-full">{product.discount}% off</span>
                  </>
                )}
              </div>

              {/* Details */}
              <div className="grid grid-cols-2 gap-3 mb-8 text-sm">
                {[
                  { label: 'Colour', value: product.colour },
                  { label: 'Merchant', value: merchantLabel },
                  ...(product.fabric ? [{ label: 'Fabric', value: product.fabric }] : []),
                  ...(product.pattern ? [{ label: 'Pattern', value: product.pattern }] : []),
                ].map(({ label, value }) => (
                  <div key={label} className="bg-white rounded-xl p-3">
                    <p className="text-xs text-[#AEB8A0] mb-0.5">{label}</p>
                    <p className="font-medium text-[#171918]">{value}</p>
                  </div>
                ))}
              </div>

              {/* Occasions */}
              <div className="mb-6">
                <p className="text-xs text-[#AEB8A0] mb-2">Occasions</p>
                <div className="flex flex-wrap gap-2">
                  {product.occasion.map(occ => (
                    <span key={occ} className="px-3 py-1 bg-[#103C35]/10 text-[#103C35] text-xs font-medium rounded-full">
                      {occ.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </span>
                  ))}
                </div>
              </div>

              {/* Style Tags */}
              <div className="mb-8">
                <div className="flex flex-wrap gap-2">
                  {product.styleTags.map(tag => (
                    <span key={tag} className="px-3 py-1 bg-[#F6F0E6] border border-[#E9E1D4] text-[#AEB8A0] text-xs rounded-full">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* CTAs */}
              <div className="space-y-3">
                {product.tryOnEnabled && (
                  <button
                    onClick={() => { setTryOnOpen(true); setTryOnProduct(product); }}
                    className="w-full flex items-center justify-center gap-2 py-4 bg-[#103C35] text-white font-semibold rounded-full hover:bg-[#0d3028] transition-colors text-sm"
                  >
                    <Sparkles size={18} />
                    ✨ TRY THIS OUTFIT ON YOU
                  </button>
                )}

                {product.affiliateUrl ? (
                  <button
                    onClick={handleShop}
                    className="w-full flex items-center justify-center gap-2 py-4 bg-[#D95E3F] text-white font-semibold rounded-full hover:bg-[#c24e31] transition-colors text-sm"
                  >
                    <ShoppingBag size={18} />
                    SHOP THIS OUTFIT on {merchantLabel}
                    <ExternalLink size={14} />
                  </button>
                ) : (
                  <div className="w-full py-4 text-center bg-[#E9E1D4] text-[#AEB8A0] text-sm rounded-full">
                    Affiliate link not configured
                  </div>
                )}

                <div className="flex gap-3">
                  <button
                    onClick={handleSave}
                    className={`flex-1 flex items-center justify-center gap-2 py-3 border text-sm font-medium rounded-full transition-colors ${
                      saved
                        ? 'border-[#D95E3F] text-[#D95E3F]'
                        : 'border-[#E9E1D4] text-[#171918] hover:border-[#D95E3F] hover:text-[#D95E3F]'
                    }`}
                  >
                    <Heart size={16} fill={saved ? 'currentColor' : 'none'} />
                    {saved ? 'Saved' : 'Save Look'}
                  </button>
                  <button
                    onClick={handleShare}
                    className="flex-1 flex items-center justify-center gap-2 py-3 border border-[#E9E1D4] text-sm font-medium text-[#171918] rounded-full hover:border-[#103C35] transition-colors"
                  >
                    <Share2 size={16} />
                    Share
                  </button>
                </div>
              </div>

              {/* Why we picked it */}
              {product.description && (
                <div className="mt-10 p-6 bg-white rounded-2xl">
                  <p className="text-xs font-semibold tracking-widest text-[#B7945A] uppercase mb-3">Why We Picked It</p>
                  <p className="text-sm text-[#171918] leading-relaxed">{product.description}</p>
                </div>
              )}

              {/* Affiliate note */}
              <p className="mt-4 text-xs text-[#AEB8A0] text-center">
                VIRAAS may earn a commission when you shop through affiliate links.
              </p>
            </div>
          </div>

          {/* Complete the Look */}
          {accessories.length > 0 && (
            <div className="mt-20">
              <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-3">Accessorise It</p>
              <h2 className="font-playfair text-2xl lg:text-3xl text-[#171918] mb-8">Complete the Look</h2>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {accessories.map(p => (
                  <ProductCard key={p.id} product={p} onTryOn={setTryOnProduct} />
                ))}
              </div>
            </div>
          )}

          {/* You May Also Like */}
          {related.length > 0 && (
            <div className="mt-20">
              <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-3">Curated for You</p>
              <h2 className="font-playfair text-2xl lg:text-3xl text-[#171918] mb-8">You May Also Like</h2>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {related.map(p => (
                  <ProductCard key={p.id} product={p} onTryOn={setTryOnProduct} />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* TryOn */}
      {tryOnOpen && tryOnProduct && (
        <TryOnModal product={tryOnProduct} onClose={() => { setTryOnOpen(false); setTryOnProduct(null); }} />
      )}
      {!tryOnOpen && tryOnProduct && (
        <TryOnModal product={tryOnProduct} onClose={() => setTryOnProduct(null)} />
      )}
    </>
  );
}
