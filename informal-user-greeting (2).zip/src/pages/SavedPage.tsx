import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Heart } from 'lucide-react';
import { getSavedLooks } from '../utils/savedLooks';
import { getProductById } from '../data/products';
import ProductCard from '../components/ProductCard';
import TryOnModal from '../components/TryOnModal';
import { type Product } from '../data/products';

export default function SavedPage() {
  const [savedIds, setSavedIds] = useState<string[]>(getSavedLooks);
  const [tryOnProduct, setTryOnProduct] = useState<Product | null>(null);

  useEffect(() => {
    setSavedIds(getSavedLooks());
  }, []);

  const savedProducts = savedIds.map(id => getProductById(id)).filter(Boolean) as Product[];

  return (
    <>
      <div className="min-h-screen bg-[#F6F0E6] pt-16 lg:pt-20">
        <div className="max-w-screen-xl mx-auto px-4 sm:px-8 py-16">
          <div className="mb-12">
            <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-3">Your Collection</p>
            <div className="flex items-center gap-3">
              <Heart size={28} className="text-[#D95E3F]" fill="currentColor" />
              <h1 className="font-playfair text-3xl lg:text-5xl text-[#171918]">My Saved Looks</h1>
            </div>
          </div>

          {savedProducts.length === 0 ? (
            <div className="text-center py-24">
              <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-[#D95E3F]/10 flex items-center justify-center">
                <Heart size={32} className="text-[#D95E3F]" />
              </div>
              <h2 className="font-playfair text-2xl text-[#171918] mb-4">No saved looks yet</h2>
              <p className="text-[#AEB8A0] mb-8 max-w-sm mx-auto">
                Browse our collections and tap the heart on any product to save it here.
              </p>
              <div className="flex justify-center gap-4 flex-wrap">
                <Link
                  to="/women"
                  className="px-8 py-3.5 bg-[#103C35] text-white font-semibold rounded-full hover:bg-[#0d3028] transition-colors"
                >
                  Browse Women
                </Link>
                <Link
                  to="/men"
                  className="px-8 py-3.5 border border-[#103C35] text-[#103C35] font-semibold rounded-full hover:bg-[#103C35] hover:text-white transition-colors"
                >
                  Browse Men
                </Link>
              </div>
            </div>
          ) : (
            <div>
              <p className="text-sm text-[#AEB8A0] mb-8">{savedProducts.length} saved look{savedProducts.length !== 1 ? 's' : ''}</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                {savedProducts.map(product => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onTryOn={setTryOnProduct}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
      {tryOnProduct && <TryOnModal product={tryOnProduct} onClose={() => setTryOnProduct(null)} />}
    </>
  );
}
