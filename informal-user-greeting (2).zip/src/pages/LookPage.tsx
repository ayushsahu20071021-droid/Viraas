import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Sparkles, ShoppingBag, Share2 } from 'lucide-react';
import { getLookById } from '../data/looks';
import { getProductById } from '../data/products';
import ProductCard from '../components/ProductCard';
import TryOnModal from '../components/TryOnModal';
import { type Product } from '../data/products';
import { trackAffiliateClick, trackEvent } from '../utils/analytics';

export default function LookPage() {
  const { id } = useParams<{ id: string }>();
  const look = getLookById(id || '');
  const [tryOnProduct, setTryOnProduct] = useState<Product | null>(null);

  if (!look) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F6F0E6] pt-20">
        <div className="text-center">
          <h1 className="font-playfair text-3xl text-[#171918] mb-4">Look not found</h1>
          <Link to="/women" className="text-[#103C35] font-semibold hover:underline">Browse Women</Link>
        </div>
      </div>
    );
  }

  const lookProducts = look.productIds
    .map(id => getProductById(id))
    .filter(Boolean) as Product[];

  const handleShareLook = async () => {
    const shareData = {
      title: look.title,
      text: `Found my festive look on VIRAAS ✨ — ${look.title}`,
      url: window.location.href,
    };
    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(window.location.href);
        alert('Link copied!');
      }
      trackEvent('share_look', { productId: look.lookId });
    } catch { /* cancelled */ }
  };

  const handleShopLook = () => {
    lookProducts.forEach(p => {
      if (p.affiliateUrl) {
        trackAffiliateClick(p.id, p.merchant, p.category);
        window.open(p.affiliateUrl, '_blank', 'noopener,noreferrer');
      }
    });
  };

  return (
    <>
      <div className="min-h-screen bg-[#F6F0E6] pt-16 lg:pt-20">
        {/* Hero */}
        <div className="relative py-20 lg:py-32 overflow-hidden">
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url(${look.heroImage})` }}
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#171918]/70 to-[#171918]/80" />
          <div className="relative z-10 max-w-screen-xl mx-auto px-4 sm:px-8">
            <Link to="/women" className="inline-flex items-center gap-2 text-sm text-[#AEB8A0] hover:text-white transition-colors mb-8">
              <ArrowLeft size={16} /> Back
            </Link>
            <div className="max-w-2xl">
              <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-4">
                {look.occasion.replace(/-/g, ' ').toUpperCase()} · {look.style.toUpperCase()}
              </p>
              <h1 className="font-playfair text-4xl lg:text-6xl text-white mb-4">{look.title}</h1>
              <p className="text-[#AEB8A0] text-base mb-8 leading-relaxed">{look.description}</p>
              <div className="flex flex-wrap gap-4">
                {look.tryOnEligible && lookProducts[0] && (
                  <button
                    onClick={() => setTryOnProduct(lookProducts[0])}
                    className="flex items-center gap-2 px-6 py-3 bg-[#F6F0E6] text-[#103C35] font-semibold rounded-full hover:bg-white transition-colors text-sm"
                  >
                    <Sparkles size={16} /> TRY THE LOOK
                  </button>
                )}
                <button
                  onClick={handleShopLook}
                  className="flex items-center gap-2 px-6 py-3 bg-[#D95E3F] text-white font-semibold rounded-full hover:bg-[#c24e31] transition-colors text-sm"
                >
                  <ShoppingBag size={16} /> SHOP LOOK
                </button>
                <button
                  onClick={handleShareLook}
                  className="flex items-center gap-2 px-6 py-3 border border-white/30 text-white font-semibold rounded-full hover:bg-white/10 transition-colors text-sm"
                >
                  <Share2 size={16} /> SHARE
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Look details */}
        <div className="max-w-screen-xl mx-auto px-4 sm:px-8 py-16">
          <div className="grid lg:grid-cols-3 gap-10">
            {/* Look info */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-2xl p-6 sticky top-24">
                <p className="text-xs font-semibold tracking-widest text-[#B7945A] uppercase mb-5">Look Details</p>
                <div className="space-y-4">
                  {[
                    { label: 'Colour Story', value: look.colourStory },
                    { label: 'Occasion', value: look.occasion.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) },
                    { label: 'Style', value: look.style },
                    { label: 'Gender', value: look.gender.charAt(0).toUpperCase() + look.gender.slice(1) },
                    { label: 'For Age', value: look.ageSegment.join(', ') },
                  ].map(({ label, value }) => (
                    <div key={label}>
                      <p className="text-xs text-[#AEB8A0] mb-0.5">{label}</p>
                      <p className="text-sm font-medium text-[#171918]">{value}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Products */}
            <div className="lg:col-span-2">
              <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-3">Products in This Look</p>
              <h2 className="font-playfair text-2xl lg:text-3xl text-[#171918] mb-8">Shop This Look</h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {lookProducts.map(product => (
                  <ProductCard key={product.id} product={product} onTryOn={setTryOnProduct} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {tryOnProduct && <TryOnModal product={tryOnProduct} onClose={() => setTryOnProduct(null)} />}
    </>
  );
}
