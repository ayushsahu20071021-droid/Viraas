import { Link } from 'react-router-dom';
import { MessageCircle } from 'lucide-react';

const WHATSAPP_NUMBER = '919644424865';
const WHATSAPP_MESSAGE = encodeURIComponent('Hi VIRAAS, I need help finding a festive outfit.');

function PageWrapper({ title, subtitle, children }: { title: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-[#F6F0E6] pt-16 lg:pt-20">
      <div className="bg-[#171918] py-16 lg:py-20 px-4 sm:px-8 mb-12">
        <div className="max-w-3xl mx-auto">
          <h1 className="font-playfair text-3xl lg:text-5xl text-white mb-3">{title}</h1>
          {subtitle && <p className="text-[#AEB8A0]">{subtitle}</p>}
        </div>
      </div>
      <div className="max-w-3xl mx-auto px-4 sm:px-8 pb-16">
        {children}
      </div>
    </div>
  );
}

export function AboutPage() {
  return (
    <PageWrapper title="About VIRAAS" subtitle="Rooted in Tradition. Designed for Now.">
      <div className="space-y-8 text-[#171918]">
        <div className="bg-white rounded-2xl p-8">
          <h2 className="font-playfair text-2xl mb-4">What is VIRAAS?</h2>
          <p className="text-base leading-relaxed text-[#AEB8A0] mb-4">
            VIRAAS is a modern Indian fashion discovery platform. We curate festive and contemporary ethnic fashion
            from India's leading retailers — Myntra, AJIO, Flipkart, Shopsy, Meesho, and Nykaa — and present them
            as thoughtfully styled, complete looks.
          </p>
          <p className="text-base leading-relaxed text-[#AEB8A0]">
            VIRAAS does not own inventory and does not process final checkout. When you click "Shop" on a VIRAAS product,
            you are directed to the external retailer's website to complete your purchase.
          </p>
        </div>

        <div className="bg-white rounded-2xl p-8">
          <h2 className="font-playfair text-2xl mb-4">The Core Experience</h2>
          <div className="space-y-4">
            {[
              { title: 'Discover', desc: 'Browse curated Indian festive fashion organized by occasion, style, colour, and budget.' },
              { title: 'Try On', desc: 'Use our AI Try-On feature to visualize how a selected outfit might look on you before shopping.' },
              { title: 'Shop', desc: 'Click through to the external retailer to complete your purchase. VIRAAS may earn an affiliate commission.' },
            ].map(item => (
              <div key={item.title} className="flex gap-4">
                <div className="w-10 h-10 rounded-full bg-[#103C35]/10 flex items-center justify-center flex-shrink-0">
                  <span className="text-xs font-bold text-[#103C35]">→</span>
                </div>
                <div>
                  <p className="font-medium text-[#171918] mb-1">{item.title}</p>
                  <p className="text-sm text-[#AEB8A0]">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-2xl p-8">
          <h2 className="font-playfair text-2xl mb-4">Our Audience</h2>
          <p className="text-base leading-relaxed text-[#AEB8A0]">
            VIRAAS is built for young India — the 16–30 audience navigating contemporary ethnic fashion for Diwali,
            weddings, Navratri, college fests, and every celebration in between. We curate across women, men, couples,
            and accessories to offer a complete festive wardrobe discovery experience.
          </p>
        </div>
      </div>
    </PageWrapper>
  );
}

export function ContactPage() {
  return (
    <PageWrapper title="Contact" subtitle="We're here to help.">
      <div className="space-y-6">
        <div className="bg-white rounded-2xl p-8">
          <h2 className="font-playfair text-2xl mb-4">Get in Touch</h2>
          <p className="text-[#AEB8A0] mb-8">
            Need help finding a look? Have a question about a product or affiliate link? Chat with us on WhatsApp.
          </p>
          <a
            href={`https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_MESSAGE}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 px-8 py-4 bg-[#25D366] text-white font-semibold rounded-full hover:bg-[#1fba58] transition-colors"
          >
            <MessageCircle size={20} />
            CHAT WITH VIRAAS
          </a>
          <p className="text-sm text-[#AEB8A0] mt-4">WhatsApp: +91 96444 24865</p>
        </div>
      </div>
    </PageWrapper>
  );
}

export function FAQPage() {
  const faqs = [
    { q: 'Does VIRAAS sell products directly?', a: 'No. VIRAAS is a fashion discovery and curation platform. We curate and present looks, but the actual purchase happens on the external retailer\'s website (Myntra, AJIO, Flipkart, etc.).' },
    { q: 'What is the AI Try-On feature?', a: 'AI Try-On lets you upload a photo of yourself and see how a selected VIRAAS outfit might look on your body. It is available for users aged 18 and above.' },
    { q: 'Is my photo stored by VIRAAS?', a: 'Your uploaded photo is used only to generate the try-on result. Please see our AI Try-On Privacy page for full details.' },
    { q: 'Does VIRAAS earn money from my purchase?', a: 'VIRAAS may earn an affiliate commission when you purchase through our curated links. This does not affect the price you pay. See our Affiliate Disclosure for details.' },
    { q: 'Are the prices shown accurate?', a: 'Prices are curated at time of listing and may change on the retailer\'s website. Always verify the final price on the retailer\'s checkout.' },
    { q: 'Can I return a product?', a: 'Returns are handled directly by the retailer (Myntra, AJIO, etc.) according to their own return policy.' },
    { q: 'How do I contact VIRAAS?', a: 'WhatsApp us at +91 96444 24865. We\'re happy to help you find the right look.' },
  ];

  return (
    <PageWrapper title="FAQ" subtitle="Frequently asked questions.">
      <div className="space-y-4">
        {faqs.map((faq, i) => (
          <div key={i} className="bg-white rounded-2xl p-6">
            <h3 className="font-medium text-[#171918] mb-3">{faq.q}</h3>
            <p className="text-sm text-[#AEB8A0] leading-relaxed">{faq.a}</p>
          </div>
        ))}
      </div>
    </PageWrapper>
  );
}

export function PrivacyPage() {
  return (
    <PageWrapper title="Privacy Policy" subtitle="How we handle your information.">
      <div className="bg-white rounded-2xl p-8 space-y-6 text-sm text-[#AEB8A0] leading-relaxed">
        <div>
          <h2 className="font-playfair text-xl text-[#171918] mb-3">What we collect</h2>
          <p>VIRAAS does not require account registration. We do not collect personal information beyond what is necessary to operate the platform. Analytics are collected in aggregate (page views, clicks, searches) using Google Analytics and/or Meta Pixel where configured.</p>
        </div>
        <div>
          <h2 className="font-playfair text-xl text-[#171918] mb-3">AI Try-On photos</h2>
          <p>Photos uploaded for AI Try-On are used only to generate the try-on result. We do not retain, share, or publish user photos without explicit consent. See our AI Try-On Privacy page for full details.</p>
        </div>
        <div>
          <h2 className="font-playfair text-xl text-[#171918] mb-3">Affiliate links</h2>
          <p>When you click "Shop" on VIRAAS, you are redirected to an external retailer through an affiliate link. The retailer's own privacy policy applies to any data collected during your purchase.</p>
        </div>
        <div>
          <h2 className="font-playfair text-xl text-[#171918] mb-3">Cookies</h2>
          <p>VIRAAS may use cookies for analytics and saved looks (localStorage). You can clear your browser data at any time.</p>
        </div>
        <div>
          <h2 className="font-playfair text-xl text-[#171918] mb-3">Contact</h2>
          <p>For privacy questions, WhatsApp us at +91 96444 24865.</p>
        </div>
      </div>
    </PageWrapper>
  );
}

export function TermsPage() {
  return (
    <PageWrapper title="Terms of Use" subtitle="Please read before using VIRAAS.">
      <div className="bg-white rounded-2xl p-8 space-y-6 text-sm text-[#AEB8A0] leading-relaxed">
        <div>
          <h2 className="font-playfair text-xl text-[#171918] mb-3">Nature of the platform</h2>
          <p>VIRAAS is a fashion discovery and curation platform. We do not sell products directly and do not process checkout. All purchases are completed on external retailer websites.</p>
        </div>
        <div>
          <h2 className="font-playfair text-xl text-[#171918] mb-3">Affiliate commission</h2>
          <p>VIRAAS may earn an affiliate commission from qualifying purchases made through our curated links. This is disclosed on every relevant page and does not affect the price you pay.</p>
        </div>
        <div>
          <h2 className="font-playfair text-xl text-[#171918] mb-3">AI Try-On</h2>
          <p>AI Try-On is provided for visualization purposes only. Results are illustrative and may vary from the actual product appearance. VIRAAS does not guarantee accuracy of AI-generated results.</p>
        </div>
        <div>
          <h2 className="font-playfair text-xl text-[#171918] mb-3">Age restriction</h2>
          <p>Photo upload for AI Try-On is restricted to users aged 18 and above. By uploading a photo, you confirm you are 18 or older.</p>
        </div>
        <div>
          <h2 className="font-playfair text-xl text-[#171918] mb-3">Price accuracy</h2>
          <p>Prices shown on VIRAAS are curated at time of listing and may change. Always verify the final price at the retailer's checkout.</p>
        </div>
      </div>
    </PageWrapper>
  );
}

export function AffiliateDisclosurePage() {
  return (
    <PageWrapper title="Affiliate Disclosure" subtitle="How VIRAAS earns.">
      <div className="bg-white rounded-2xl p-8 text-sm text-[#AEB8A0] leading-relaxed space-y-5">
        <p className="text-base font-medium text-[#171918]">
          VIRAAS may earn a commission when you shop through selected affiliate links.
        </p>
        <p>
          When you click "Shop" on a VIRAAS product and make a purchase on the retailer's website, VIRAAS may receive
          an affiliate commission through platforms such as EarnKaro. This commission is paid by the retailer
          and does not affect the price you pay.
        </p>
        <p>
          VIRAAS curates products independently. Our curation decisions are based on style, occasion relevance,
          fabric quality, visual appeal, and value — not on commission rate.
        </p>
        <p>
          Not all products on VIRAAS have active affiliate links configured. Where no affiliate link is present,
          this is clearly indicated on the product page.
        </p>
        <p>
          Supported affiliate retailers: Myntra, AJIO, Flipkart, Shopsy, Meesho, Nykaa.
        </p>
        <div className="bg-[#103C35]/5 rounded-xl p-4 mt-4">
          <p className="text-[#103C35] font-medium text-sm">
            Questions? WhatsApp us at +91 96444 24865.
          </p>
        </div>
      </div>
    </PageWrapper>
  );
}

export function AITryOnPrivacyPage() {
  return (
    <PageWrapper title="AI Try-On Privacy" subtitle="How your photo is used.">
      <div className="bg-white rounded-2xl p-8 text-sm text-[#AEB8A0] leading-relaxed space-y-6">
        <div>
          <h2 className="font-playfair text-xl text-[#171918] mb-3">What is AI Try-On?</h2>
          <p>AI Try-On is a feature that lets you upload a personal photo and see how a selected VIRAAS outfit might look on your body using AI image processing.</p>
        </div>
        <div>
          <h2 className="font-playfair text-xl text-[#171918] mb-3">How your photo is used</h2>
          <p>Your photo is processed by the AI system to generate a try-on visualization. The AI focuses on clothing transformation while preserving your facial structure, skin tone, hairstyle, and body proportions where technically possible.</p>
        </div>
        <div>
          <h2 className="font-playfair text-xl text-[#171918] mb-3">Storage and retention</h2>
          <p>VIRAAS does not permanently store your uploaded photos. Your photo is used only during the active session to generate the result. If you close the session, the photo is no longer accessible.</p>
        </div>
        <div>
          <h2 className="font-playfair text-xl text-[#171918] mb-3">Sharing</h2>
          <p>Your uploaded photo and AI result are never automatically shared or published. If you choose to share your result, sharing is entirely under your control.</p>
        </div>
        <div>
          <h2 className="font-playfair text-xl text-[#171918] mb-3">Age restriction</h2>
          <p>Photo upload is restricted to users aged 18 and above. You will be asked to confirm your age before uploading.</p>
        </div>
        <div>
          <h2 className="font-playfair text-xl text-[#171918] mb-3">Your control</h2>
          <p>You may cancel the Try-On process at any time. You are not required to use the Try-On feature to browse or shop on VIRAAS.</p>
        </div>
      </div>
    </PageWrapper>
  );
}

export function CoupleEditPage() {
  return (
    <div className="min-h-screen bg-[#F6F0E6] pt-16 lg:pt-20">
      <div className="relative py-24 overflow-hidden">
        <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: 'url(/images/couple-edit.jpg)' }} />
        <div className="absolute inset-0 bg-gradient-to-b from-[#171918]/70 to-[#171918]/80" />
        <div className="relative z-10 max-w-screen-xl mx-auto px-4 sm:px-8 text-center">
          <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-4">Dressed Together</p>
          <h1 className="font-playfair text-5xl lg:text-7xl text-white mb-4">Couple Edit</h1>
          <p className="text-[#AEB8A0] text-base max-w-md mx-auto">Coordinated, complementary, colour-story matched. Festive dressing for two.</p>
        </div>
      </div>

      <div className="max-w-screen-xl mx-auto px-4 sm:px-8 py-16">
        {/* Ivory × Jade */}
        <div className="grid lg:grid-cols-2 gap-10 mb-20">
          <img src="/images/couple-edit.jpg" alt="Ivory × Jade Couple Look" className="rounded-3xl object-cover aspect-[4/3]" />
          <div className="flex flex-col justify-center">
            <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-3">Diwali Edit</p>
            <h2 className="font-playfair text-3xl lg:text-4xl text-[#171918] mb-4">Ivory × Jade</h2>
            <p className="text-[#AEB8A0] mb-6 leading-relaxed">
              Him in an ivory kurta with sage Nehru jacket. Her in a jade floral Anarkali. A complementary palette that photographs beautifully together.
            </p>
            <div className="space-y-3">
              <div className="flex gap-3">
                <Link to="/product/m-kurta-002" className="flex-1 py-3 bg-[#103C35] text-white text-sm font-semibold rounded-full text-center hover:bg-[#0d3028] transition-colors">
                  SHOP HIS LOOK
                </Link>
                <Link to="/product/w-kurta-001" className="flex-1 py-3 bg-[#AEB8A0] text-white text-sm font-semibold rounded-full text-center hover:bg-[#9aab8e] transition-colors">
                  SHOP HER LOOK
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* More couple inspiration */}
        <div className="text-center py-12 bg-white rounded-3xl">
          <p className="font-playfair text-2xl text-[#171918] mb-4">More Couple Looks Coming Soon</p>
          <p className="text-[#AEB8A0] mb-8">Explore individual collections while we curate more couple edits.</p>
          <div className="flex justify-center gap-4 flex-wrap">
            <Link to="/women" className="px-8 py-3 bg-[#103C35] text-white font-semibold rounded-full hover:bg-[#0d3028] transition-colors text-sm">
              Shop Women
            </Link>
            <Link to="/men" className="px-8 py-3 border border-[#103C35] text-[#103C35] font-semibold rounded-full hover:bg-[#103C35] hover:text-white transition-colors text-sm">
              Shop Men
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export function TrendingPage() {
  return (
    <div className="min-h-screen bg-[#F6F0E6] pt-16 lg:pt-20">
      <div className="bg-[#171918] py-20 px-4 sm:px-8 mb-12">
        <div className="max-w-screen-xl mx-auto">
          <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-4">The Edit</p>
          <h1 className="font-playfair text-4xl lg:text-6xl text-white">Trending Now</h1>
        </div>
      </div>

      <div className="max-w-screen-xl mx-auto px-4 sm:px-8 pb-16">
        {/* Trend collections */}
        {[
          { title: 'The Jade Edit', desc: 'Sage, jade and emerald — the green spectrum is leading festive dressing this season.' },
          { title: 'The Ivory Edit', desc: 'Minimal ivory with gold accents — understated luxury for weddings and receptions.' },
          { title: 'Modern Drapes', desc: 'Pre-draped sarees and concept drapes — the new take on traditional silhouettes.' },
          { title: 'Festive Co-ords', desc: 'Matching sets in festive fabrics — easy, complete, contemporary.' },
        ].map(collection => (
          <div key={collection.title} className="mb-8 p-6 bg-white rounded-2xl flex items-center justify-between gap-4">
            <div>
              <h3 className="font-playfair text-xl text-[#171918] mb-1">{collection.title}</h3>
              <p className="text-sm text-[#AEB8A0]">{collection.desc}</p>
            </div>
            <Link to="/women" className="flex-shrink-0 px-5 py-2 bg-[#103C35] text-white text-sm font-semibold rounded-full hover:bg-[#0d3028] transition-colors">
              Explore
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}
