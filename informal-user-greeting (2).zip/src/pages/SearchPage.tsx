import { useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Search } from 'lucide-react';
import { searchProducts } from '../data/products';
import ProductCard from '../components/ProductCard';
import TryOnModal from '../components/TryOnModal';
import { type Product } from '../data/products';

export default function SearchPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [tryOnProduct, setTryOnProduct] = useState<Product | null>(null);
  const q = searchParams.get('q') || '';
  const results = q ? searchProducts(q) : [];

  const suggestions = ['Diwali outfits', 'Pre-draped saree', 'Kurta jacket', 'Navratri look', 'Wedding guest', 'Jade Anarkali', 'Ivory kurta', 'Mirror work'];

  return (
    <>
      <div className="min-h-screen bg-[#F6F0E6] pt-16 lg:pt-20">
        {/* Search bar */}
        <div className="bg-white border-b border-[#E9E1D4] sticky top-16 lg:top-20 z-20">
          <div className="max-w-screen-xl mx-auto px-4 sm:px-8 py-4">
            <form
              onSubmit={e => {
                e.preventDefault();
                const input = (e.currentTarget.elements.namedItem('q') as HTMLInputElement).value;
                if (input.trim()) setSearchParams({ q: input.trim() });
              }}
              className="flex items-center gap-3 bg-[#F6F0E6] rounded-full px-5 py-3"
            >
              <Search size={18} className="text-[#AEB8A0]" />
              <input
                name="q"
                defaultValue={q}
                placeholder="Search outfits, occasions, colours…"
                className="flex-1 bg-transparent text-[#171918] placeholder-[#AEB8A0] outline-none text-base"
              />
              <button type="submit" className="text-sm font-semibold text-[#103C35] hover:text-[#D95E3F] transition-colors">
                Search
              </button>
            </form>
          </div>
        </div>

        <div className="max-w-screen-xl mx-auto px-4 sm:px-8 py-12">
          {!q ? (
            <div>
              <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-6">Popular Searches</p>
              <div className="flex flex-wrap gap-3">
                {suggestions.map(s => (
                  <button
                    key={s}
                    onClick={() => setSearchParams({ q: s })}
                    className="px-5 py-2.5 bg-white border border-[#E9E1D4] text-sm text-[#171918] rounded-full hover:border-[#103C35] hover:text-[#103C35] transition-colors"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : results.length === 0 ? (
            <div className="text-center py-20">
              <p className="font-playfair text-2xl text-[#171918] mb-4">No results for "{q}"</p>
              <p className="text-[#AEB8A0] mb-8">Try a different search term or browse our collections.</p>
              <div className="flex justify-center gap-4">
                <Link to="/women" className="px-6 py-3 bg-[#103C35] text-white font-semibold rounded-full hover:bg-[#0d3028] transition-colors text-sm">
                  Browse Women
                </Link>
                <Link to="/men" className="px-6 py-3 border border-[#103C35] text-[#103C35] font-semibold rounded-full hover:bg-[#103C35] hover:text-white transition-colors text-sm">
                  Browse Men
                </Link>
              </div>
            </div>
          ) : (
            <div>
              <p className="text-sm text-[#AEB8A0] mb-8">
                {results.length} result{results.length !== 1 ? 's' : ''} for <strong className="text-[#171918]">"{q}"</strong>
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                {results.map(product => (
                  <ProductCard key={product.id} product={product} onTryOn={setTryOnProduct} />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
      {tryOnProduct && <TryOnModal product={tryOnProduct} onClose={() => setTryOnProduct(null)} />}
    </>
  );
}
