import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Clock } from 'lucide-react';
import { articles } from '../data/articles';
import { products } from '../data/products';
import ProductCard from '../components/ProductCard';
import { useState } from 'react';
import TryOnModal from '../components/TryOnModal';
import { type Product } from '../data/products';

export default function JournalPage() {
  const { slug } = useParams<{ slug?: string }>();
  const [tryOnProduct, setTryOnProduct] = useState<Product | null>(null);

  if (slug) {
    const article = articles.find(a => a.slug === slug);
    if (!article) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-[#F6F0E6] pt-20">
          <div className="text-center">
            <h1 className="font-playfair text-3xl text-[#171918] mb-4">Article not found</h1>
            <Link to="/journal" className="text-[#103C35] font-semibold hover:underline">Back to Journal</Link>
          </div>
        </div>
      );
    }

    const relatedProducts = products.filter(p =>
      article.tags.some(tag =>
        p.category.toLowerCase().includes(tag.toLowerCase()) ||
        p.styleTags.some(st => st.toLowerCase().includes(tag.toLowerCase())) ||
        p.occasion.some(o => o.toLowerCase().includes(tag.toLowerCase()))
      )
    ).slice(0, 4);

    return (
      <>
        <div className="min-h-screen bg-[#F6F0E6] pt-16 lg:pt-20">
          {/* Hero */}
          <div className="relative py-20 lg:py-28 overflow-hidden">
            <div
              className="absolute inset-0 bg-cover bg-center"
              style={{ backgroundImage: `url(${article.image})` }}
            />
            <div className="absolute inset-0 bg-gradient-to-b from-[#171918]/80 to-[#171918]/70" />
            <div className="relative z-10 max-w-3xl mx-auto px-4 sm:px-8 text-center">
              <div className="flex items-center justify-center gap-3 mb-6">
                <span className="text-xs font-semibold text-[#B7945A] uppercase tracking-widest">{article.category}</span>
                <span className="text-[#AEB8A0]">·</span>
                <span className="flex items-center gap-1 text-xs text-[#AEB8A0]">
                  <Clock size={12} /> {article.readTime} read
                </span>
              </div>
              <h1 className="font-playfair text-3xl lg:text-5xl text-white leading-tight mb-6">{article.title}</h1>
              <p className="text-[#AEB8A0] text-base">{article.excerpt}</p>
            </div>
          </div>

          {/* Back */}
          <div className="max-w-3xl mx-auto px-4 sm:px-8 py-8">
            <Link to="/journal" className="inline-flex items-center gap-2 text-sm text-[#AEB8A0] hover:text-[#103C35] transition-colors">
              <ArrowLeft size={16} /> Back to Journal
            </Link>
          </div>

          {/* Article body — placeholder editorial content */}
          <article className="max-w-3xl mx-auto px-4 sm:px-8 pb-16">
            <div className="prose prose-lg max-w-none">
              <p className="text-[#171918] text-base leading-relaxed mb-6">
                {article.excerpt} This year, the conversation around Indian festive fashion has shifted considerably.
                Rather than following heavy trend cycles, the new approach is more considered — selecting pieces that balance cultural significance with contemporary wearability.
              </p>
              <h2 className="font-playfair text-2xl text-[#171918] mt-10 mb-4">The VIRAAS Perspective</h2>
              <p className="text-[#171918] text-base leading-relaxed mb-6">
                At VIRAAS, we approach festive curation differently. Every piece we select has a reason for being here — whether it's the silhouette, the craft, the colour story, or its occasion relevance.
                We're not interested in trends for their own sake. We're interested in looks that make sense for real moments — a Diwali dinner, a sangeet morning, a college fest.
              </p>
              <h2 className="font-playfair text-2xl text-[#171918] mt-10 mb-4">What to Look For</h2>
              <ul className="space-y-3 mb-6">
                {['Fabric that photographs well and feels comfortable through a long evening.',
                  'Silhouettes that work for your body and movement — not just a hanger.',
                  'Colour stories that complement your skin tone and the occasion lighting.',
                  'Accessories that complete without overwhelming the central outfit.'].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <span className="w-2 h-2 mt-2 rounded-full bg-[#D95E3F] flex-shrink-0" />
                    <span className="text-[#171918] text-base">{item}</span>
                  </li>
                ))}
              </ul>
              <h2 className="font-playfair text-2xl text-[#171918] mt-10 mb-4">The Try-On Advantage</h2>
              <p className="text-[#171918] text-base leading-relaxed mb-6">
                One of the most common pain points in online festive shopping is uncertainty — does this lehenga actually work for my body type?
                Will this shade of jade look different on me? VIRAAS's AI Try-On feature is designed to reduce exactly that uncertainty.
                Choose a product, upload a photo, and see how the look translates before you shop.
              </p>
              <div className="bg-[#103C35]/5 border border-[#103C35]/10 rounded-2xl p-6 my-8">
                <p className="font-playfair text-xl text-[#103C35] mb-3">Discover → Try On → Shop</p>
                <p className="text-sm text-[#AEB8A0]">The complete VIRAAS experience — from editorial discovery to AI visualization to actual shopping through your preferred retailer.</p>
              </div>
            </div>

            {/* Related products */}
            {relatedProducts.length > 0 && (
              <div className="mt-16">
                <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-3">Shop the Edit</p>
                <h3 className="font-playfair text-2xl text-[#171918] mb-8">Related Looks</h3>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  {relatedProducts.map(p => (
                    <ProductCard key={p.id} product={p} onTryOn={setTryOnProduct} />
                  ))}
                </div>
              </div>
            )}

            {/* Tags */}
            <div className="mt-10 flex flex-wrap gap-2">
              {article.tags.map(tag => (
                <span key={tag} className="px-3 py-1 bg-[#E9E1D4] text-[#AEB8A0] text-xs rounded-full">{tag}</span>
              ))}
            </div>
          </article>
        </div>
        {tryOnProduct && <TryOnModal product={tryOnProduct} onClose={() => setTryOnProduct(null)} />}
      </>
    );
  }

  // All articles
  return (
    <div className="min-h-screen bg-[#F6F0E6] pt-16 lg:pt-20">
      {/* Hero */}
      <div className="bg-[#171918] py-20 lg:py-28 px-4 sm:px-8">
        <div className="max-w-screen-xl mx-auto">
          <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-4">The VIRAAS Journal</p>
          <h1 className="font-playfair text-4xl lg:text-7xl text-white">Style Stories</h1>
        </div>
      </div>

      {/* Featured */}
      {articles[0] && (
        <div className="max-w-screen-xl mx-auto px-4 sm:px-8 py-12">
          <Link to={`/journal/${articles[0].slug}`} className="group grid lg:grid-cols-2 gap-8 items-center">
            <div className="relative aspect-video lg:aspect-[4/3] rounded-2xl overflow-hidden bg-[#E9E1D4]">
              <img
                src={articles[0].image}
                alt={articles[0].title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
            </div>
            <div>
              <div className="flex items-center gap-3 mb-4">
                <span className="text-xs font-semibold text-[#B7945A] uppercase tracking-widest">{articles[0].category}</span>
                <span className="text-[#E9E1D4]">·</span>
                <span className="text-xs text-[#AEB8A0]">{articles[0].readTime} read</span>
              </div>
              <h2 className="font-playfair text-3xl lg:text-4xl text-[#171918] mb-4 group-hover:text-[#103C35] transition-colors">
                {articles[0].title}
              </h2>
              <p className="text-[#AEB8A0] text-base leading-relaxed mb-6">{articles[0].excerpt}</p>
              <span className="inline-flex items-center gap-2 text-sm font-semibold text-[#103C35] group-hover:text-[#D95E3F] transition-colors">
                Read Article <ArrowRight size={16} />
              </span>
            </div>
          </Link>
        </div>
      )}

      {/* Grid */}
      <div className="max-w-screen-xl mx-auto px-4 sm:px-8 pb-16">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {articles.slice(1).map(article => (
            <Link key={article.id} to={`/journal/${article.slug}`} className="group">
              <div className="relative aspect-[4/3] rounded-2xl overflow-hidden bg-[#E9E1D4] mb-5">
                <img
                  src={article.image}
                  alt={article.title}
                  loading="lazy"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="flex items-center gap-3 mb-2">
                <span className="text-xs font-semibold text-[#B7945A] uppercase tracking-widest">{article.category}</span>
                <span className="text-xs text-[#AEB8A0]">{article.readTime} read</span>
              </div>
              <h3 className="font-playfair text-xl text-[#171918] mb-2 group-hover:text-[#103C35] transition-colors leading-snug">
                {article.title}
              </h3>
              <p className="text-sm text-[#AEB8A0] line-clamp-2">{article.excerpt}</p>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
