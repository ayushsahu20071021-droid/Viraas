import { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { SlidersHorizontal, X, ChevronDown } from 'lucide-react';
import { products, type Gender } from '../data/products';
import ProductCard from '../components/ProductCard';
import TryOnModal from '../components/TryOnModal';
import { type Product } from '../data/products';

interface Props {
  gender: Gender;
  title: string;
  subtitle: string;
  heroImage: string;
}

const PRICE_RANGES = [
  { label: 'Under ₹499', max: 499 },
  { label: 'Under ₹799', max: 799 },
  { label: 'Under ₹999', max: 999 },
  { label: 'Under ₹1,499', max: 1499 },
  { label: 'Under ₹1,999', max: 1999 },
  { label: '₹1,999–₹2,999', min: 1999, max: 2999 },
  { label: '₹2,999–₹4,999', min: 2999, max: 4999 },
  { label: '₹5,000+', min: 5000 },
];

const SORT_OPTIONS = [
  { value: 'recommended', label: 'Recommended' },
  { value: 'price-low', label: 'Price: Low to High' },
  { value: 'price-high', label: 'Price: High to Low' },
  { value: 'discount', label: 'Discount' },
];

export default function CategoryPage({ gender, title, subtitle, heroImage }: Props) {
  const [searchParams] = useSearchParams();
  const [tryOnProduct, setTryOnProduct] = useState<Product | null>(null);
  const [filterOpen, setFilterOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get('category') || '');
  const [selectedOccasion, setSelectedOccasion] = useState('');
  const [selectedColour, setSelectedColour] = useState('');
  const [selectedPrice, setSelectedPrice] = useState('');
  const [sortBy, setSortBy] = useState('recommended');
  const [page, setPage] = useState(1);
  const PER_PAGE = 12;

  const genderProducts = products.filter(p =>
    gender === 'accessories'
      ? p.category === 'accessories' || p.category === 'footwear'
      : p.gender === gender
  );

  const categories = [...new Set(genderProducts.map(p => p.category))];
  const occasions = [...new Set(genderProducts.flatMap(p => p.occasion))];
  const colours = [...new Set(genderProducts.map(p => p.colour))];

  const filtered = useMemo(() => {
    let list = [...genderProducts];
    if (selectedCategory) list = list.filter(p => p.category === selectedCategory);
    if (selectedOccasion) list = list.filter(p => p.occasion.includes(selectedOccasion));
    if (selectedColour) list = list.filter(p => p.colour === selectedColour);
    if (selectedPrice) {
      const range = PRICE_RANGES.find(r => r.label === selectedPrice);
      if (range) {
        list = list.filter(p =>
          (range.min === undefined || p.price >= range.min) &&
          (range.max === undefined || p.price <= range.max)
        );
      }
    }

    if (sortBy === 'price-low') list.sort((a, b) => a.price - b.price);
    else if (sortBy === 'price-high') list.sort((a, b) => b.price - a.price);
    else if (sortBy === 'discount') list.sort((a, b) => b.discount - a.discount);

    return list;
  }, [genderProducts, selectedCategory, selectedOccasion, selectedColour, selectedPrice, sortBy]);

  const paginated = filtered.slice(0, page * PER_PAGE);
  const hasMore = paginated.length < filtered.length;

  const clearFilters = () => {
    setSelectedCategory('');
    setSelectedOccasion('');
    setSelectedColour('');
    setSelectedPrice('');
  };

  const activeFilters = [selectedCategory, selectedOccasion, selectedColour, selectedPrice].filter(Boolean).length;

  return (
    <>
      {/* Hero */}
      <section className="relative pt-20 pb-16 lg:pt-24 lg:pb-20 overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${heroImage})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#171918]/70 to-[#171918]/50" />
        <div className="relative z-10 max-w-screen-xl mx-auto px-4 sm:px-8 text-center">
          <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-4">VIRAAS</p>
          <h1 className="font-playfair text-4xl lg:text-6xl text-white mb-4">{title}</h1>
          <p className="text-[#AEB8A0] text-base max-w-md mx-auto">{subtitle}</p>
        </div>
      </section>

      {/* Filter + Grid */}
      <section className="bg-[#F6F0E6] min-h-screen">
        {/* Filter Bar */}
        <div className="sticky top-16 lg:top-20 z-30 bg-[#F6F0E6]/95 backdrop-blur-sm border-b border-[#E9E1D4]">
          <div className="max-w-screen-xl mx-auto px-4 sm:px-8 py-3 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 overflow-x-auto scrollbar-hide">
              <button
                onClick={() => setFilterOpen(!filterOpen)}
                className="flex items-center gap-2 px-4 py-2 bg-white border border-[#E9E1D4] rounded-full text-sm font-medium text-[#171918] hover:border-[#103C35] transition-colors flex-shrink-0"
              >
                <SlidersHorizontal size={15} />
                Filters
                {activeFilters > 0 && (
                  <span className="w-5 h-5 flex items-center justify-center bg-[#D95E3F] text-white text-xs rounded-full">
                    {activeFilters}
                  </span>
                )}
              </button>

              {/* Quick filters */}
              {categories.slice(0, 4).map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(selectedCategory === cat ? '' : cat)}
                  className={`px-4 py-2 rounded-full text-sm font-medium flex-shrink-0 transition-colors ${
                    selectedCategory === cat
                      ? 'bg-[#103C35] text-white'
                      : 'bg-white border border-[#E9E1D4] text-[#171918] hover:border-[#103C35]'
                  }`}
                >
                  {cat.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-3 flex-shrink-0">
              <p className="text-sm text-[#AEB8A0] hidden sm:block">{filtered.length} items</p>
              <div className="relative">
                <select
                  value={sortBy}
                  onChange={e => setSortBy(e.target.value)}
                  className="appearance-none pl-3 pr-8 py-2 bg-white border border-[#E9E1D4] rounded-full text-sm text-[#171918] cursor-pointer outline-none"
                >
                  {SORT_OPTIONS.map(o => (
                    <option key={o.value} value={o.value}>{o.label}</option>
                  ))}
                </select>
                <ChevronDown size={14} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#AEB8A0] pointer-events-none" />
              </div>
            </div>
          </div>
        </div>

        {/* Filter Panel */}
        {filterOpen && (
          <div className="bg-white border-b border-[#E9E1D4] shadow-sm">
            <div className="max-w-screen-xl mx-auto px-4 sm:px-8 py-6 grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {/* Category */}
              <div>
                <p className="text-xs font-semibold tracking-widest text-[#B7945A] uppercase mb-3">Category</p>
                <div className="space-y-2">
                  {categories.map(cat => (
                    <label key={cat} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="category"
                        checked={selectedCategory === cat}
                        onChange={() => setSelectedCategory(selectedCategory === cat ? '' : cat)}
                        className="accent-[#103C35]"
                      />
                      <span className="text-sm text-[#171918]">{cat.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Occasion */}
              <div>
                <p className="text-xs font-semibold tracking-widest text-[#B7945A] uppercase mb-3">Occasion</p>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {occasions.map(occ => (
                    <label key={occ} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="occasion"
                        checked={selectedOccasion === occ}
                        onChange={() => setSelectedOccasion(selectedOccasion === occ ? '' : occ)}
                        className="accent-[#103C35]"
                      />
                      <span className="text-sm text-[#171918]">{occ.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Colour */}
              <div>
                <p className="text-xs font-semibold tracking-widest text-[#B7945A] uppercase mb-3">Colour</p>
                <div className="flex flex-wrap gap-2">
                  {colours.map(colour => (
                    <button
                      key={colour}
                      onClick={() => setSelectedColour(selectedColour === colour ? '' : colour)}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                        selectedColour === colour
                          ? 'bg-[#103C35] text-white'
                          : 'bg-[#F6F0E6] text-[#171918] hover:bg-[#E9E1D4]'
                      }`}
                    >
                      {colour}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price */}
              <div>
                <p className="text-xs font-semibold tracking-widest text-[#B7945A] uppercase mb-3">Budget</p>
                <div className="space-y-2">
                  {PRICE_RANGES.map(range => (
                    <label key={range.label} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="price"
                        checked={selectedPrice === range.label}
                        onChange={() => setSelectedPrice(selectedPrice === range.label ? '' : range.label)}
                        className="accent-[#103C35]"
                      />
                      <span className="text-sm text-[#171918]">{range.label}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
            {activeFilters > 0 && (
              <div className="max-w-screen-xl mx-auto px-4 sm:px-8 pb-4">
                <button
                  onClick={clearFilters}
                  className="flex items-center gap-1.5 text-sm text-[#D95E3F] font-medium hover:underline"
                >
                  <X size={14} /> Clear all filters
                </button>
              </div>
            )}
          </div>
        )}

        {/* Product Grid */}
        <div className="max-w-screen-xl mx-auto px-4 sm:px-8 py-10">
          {filtered.length === 0 ? (
            <div className="text-center py-24">
              <p className="font-playfair text-2xl text-[#171918] mb-4">No looks matched those filters.</p>
              <p className="text-[#AEB8A0] mb-8">Try adjusting or clearing your filters.</p>
              <button
                onClick={clearFilters}
                className="px-8 py-3 bg-[#103C35] text-white font-semibold rounded-full hover:bg-[#0d3028] transition-colors"
              >
                CLEAR FILTERS
              </button>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 lg:gap-6">
                {paginated.map(product => (
                  <ProductCard key={product.id} product={product} onTryOn={setTryOnProduct} />
                ))}
              </div>
              {hasMore && (
                <div className="mt-12 text-center">
                  <button
                    onClick={() => setPage(p => p + 1)}
                    className="px-10 py-3.5 border-2 border-[#103C35] text-[#103C35] font-semibold rounded-full hover:bg-[#103C35] hover:text-white transition-colors"
                  >
                    Load More
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </section>

      {tryOnProduct && (
        <TryOnModal product={tryOnProduct} onClose={() => setTryOnProduct(null)} />
      )}
    </>
  );
}
