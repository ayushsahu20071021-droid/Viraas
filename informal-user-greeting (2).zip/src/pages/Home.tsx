import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Sparkles, ChevronDown } from 'lucide-react';
import { products } from '../data/products';
import { getFeaturedLooks } from '../data/looks';
import { getFeaturedOccasions } from '../data/occasions';
import { articles } from '../data/articles';
import ProductCard from '../components/ProductCard';
import TryOnModal from '../components/TryOnModal';
import { type Product } from '../data/products';

const WHATSAPP_NUMBER = '919644424865';
const WHATSAPP_MESSAGE = encodeURIComponent('Hi VIRAAS, I need help finding a festive outfit.');

export default function Home() {
  const [tryOnProduct, setTryOnProduct] = useState<Product | null>(null);

  const featuredOccasions = getFeaturedOccasions();
  const featuredLooks = getFeaturedLooks();
  const womenProducts = products.filter(p => p.gender === 'women').slice(0, 6);
  const menProducts = products.filter(p => p.gender === 'men').slice(0, 6);
  const trendingProducts = products.filter(p => p.styleTags.includes('Pinterest Inspired')).slice(0, 4);

  const accessoryProducts = products.filter(p => p.category === 'accessories').slice(0, 4);

  return (
    <>
      {/* HERO */}
      <section className="relative min-h-screen flex items-end overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: 'url(/images/hero-main.jpg)' }}
        />
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#171918]/90 via-[#171918]/30 to-transparent" />

        {/* Content */}
        <div className="relative z-10 w-full max-w-screen-xl mx-auto px-4 sm:px-8 pb-20 lg:pb-28">
          <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-5">
            The Festive Edit '26
          </p>
          <h1 className="font-playfair text-5xl sm:text-6xl lg:text-8xl font-bold text-white leading-tight mb-5 max-w-3xl">
            Tradition,<br />
            <em className="font-normal">reimagined</em><br />
            for now.
          </h1>
          <p className="text-[#E9E1D4]/80 text-base lg:text-lg max-w-md mb-10 leading-relaxed">
            Discover curated Indian fashion. See it on you. Shop the real outfit from India's top retailers.
          </p>
          <div className="flex flex-wrap gap-4">
            <Link
              to="/women"
              className="px-8 py-3.5 bg-[#F6F0E6] text-[#103C35] font-semibold text-sm rounded-full hover:bg-white transition-colors"
            >
              SHOP WOMEN
            </Link>
            <Link
              to="/men"
              className="px-8 py-3.5 border border-white/50 text-white font-semibold text-sm rounded-full hover:bg-white/10 transition-colors"
            >
              SHOP MEN
            </Link>
            <Link
              to="/try-on"
              className="flex items-center gap-2 px-8 py-3.5 bg-[#D95E3F] text-white font-semibold text-sm rounded-full hover:bg-[#c24e31] transition-colors"
            >
              <Sparkles size={16} />
              TRY AN OUTFIT ON YOU
            </Link>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 text-white/50 animate-bounce">
          <ChevronDown size={20} />
        </div>
      </section>

      {/* OCCASION DISCOVERY */}
      <section className="py-20 lg:py-28 bg-[#F6F0E6] px-4 sm:px-8">
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-end justify-between mb-12">
            <div>
              <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-3">Shop by Occasion</p>
              <h2 className="font-playfair text-3xl lg:text-5xl text-[#171918]">
                Dress for<br />the Moment
              </h2>
            </div>
            <Link to="/occasions" className="hidden sm:flex items-center gap-2 text-sm text-[#103C35] font-semibold hover:text-[#D95E3F] transition-colors">
              All Occasions <ArrowRight size={16} />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 lg:gap-4">
            {featuredOccasions.map(occasion => (
              <Link
                key={occasion.id}
                to={`/occasions/${occasion.id}`}
                className="group relative rounded-2xl overflow-hidden aspect-[3/4] bg-[#E9E1D4]"
              >
                <img
                  src={occasion.image}
                  alt={occasion.title}
                  loading="lazy"
                  className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#171918]/80 via-[#171918]/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <p className="text-white font-playfair font-medium text-base">{occasion.title}</p>
                  <p className="text-[#AEB8A0] text-xs mt-0.5 line-clamp-1">{occasion.subtitle}</p>
                </div>
              </Link>
            ))}
          </div>
          <div className="sm:hidden mt-6 text-center">
            <Link to="/occasions" className="inline-flex items-center gap-2 text-sm text-[#103C35] font-semibold">
              All Occasions <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* FOR HER */}
      <section className="py-20 lg:py-28 bg-white px-4 sm:px-8">
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-end justify-between mb-12">
            <div>
              <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-3">Women's Edit</p>
              <h2 className="font-playfair text-3xl lg:text-5xl text-[#171918]">For Her</h2>
              <p className="text-[#AEB8A0] mt-2">Indian silhouettes, styled for now.</p>
            </div>
            <Link to="/women" className="hidden sm:flex items-center gap-2 text-sm text-[#103C35] font-semibold hover:text-[#D95E3F] transition-colors">
              View All <ArrowRight size={16} />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-6 gap-4">
            {womenProducts.map(product => (
              <ProductCard key={product.id} product={product} onTryOn={setTryOnProduct} />
            ))}
          </div>
          <div className="sm:hidden mt-6 text-center">
            <Link to="/women" className="inline-flex items-center gap-2 text-sm text-[#103C35] font-semibold">
              View All Women <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* FOR HIM */}
      <section className="py-20 lg:py-28 bg-[#F6F0E6] px-4 sm:px-8">
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-end justify-between mb-12">
            <div>
              <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-3">Men's Edit</p>
              <h2 className="font-playfair text-3xl lg:text-5xl text-[#171918]">For Him</h2>
              <p className="text-[#AEB8A0] mt-2">Modern festive tailoring, rooted in tradition.</p>
            </div>
            <Link to="/men" className="hidden sm:flex items-center gap-2 text-sm text-[#103C35] font-semibold hover:text-[#D95E3F] transition-colors">
              View All <ArrowRight size={16} />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-6 gap-4">
            {menProducts.map(product => (
              <ProductCard key={product.id} product={product} onTryOn={setTryOnProduct} />
            ))}
          </div>
        </div>
      </section>

      {/* AI TRY-ON */}
      <section className="py-20 lg:py-28 bg-[#103C35] px-4 sm:px-8 overflow-hidden">
        <div className="max-w-screen-xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Text */}
            <div>
              <div className="flex items-center gap-2 mb-5">
                <Sparkles size={18} className="text-[#D95E3F]" />
                <p className="text-xs font-semibold tracking-[0.3em] text-[#AEB8A0] uppercase">AI-Powered</p>
              </div>
              <h2 className="font-playfair text-3xl lg:text-5xl text-white mb-6 leading-tight">
                See It<br /><em>On You</em>
              </h2>
              <p className="text-[#AEB8A0] text-base leading-relaxed mb-8 max-w-md">
                Love the outfit? See how the look could translate to you. Choose a product, upload a photo, and let AI visualize the outfit on your body.
              </p>
              {/* Flow */}
              <div className="flex items-center gap-3 mb-10 flex-wrap">
                {['Choose Outfit', 'Upload Photo', 'AI Try-On', 'Save & Shop'].map((step, i) => (
                  <div key={step} className="flex items-center gap-3">
                    <div className="flex flex-col items-center">
                      <div className="w-8 h-8 rounded-full bg-[#D95E3F]/20 flex items-center justify-center text-[#D95E3F] text-sm font-bold">
                        {i + 1}
                      </div>
                      <span className="text-xs text-[#AEB8A0] mt-1">{step}</span>
                    </div>
                    {i < 3 && <div className="w-8 h-px bg-[#AEB8A0]/30 mt-0 -mt-4" />}
                  </div>
                ))}
              </div>
              <Link
                to="/try-on"
                className="inline-flex items-center gap-2 px-8 py-4 bg-[#D95E3F] text-white font-semibold rounded-full hover:bg-[#c24e31] transition-colors"
              >
                <Sparkles size={18} />
                TRY A LOOK NOW
              </Link>
            </div>

            {/* Visual */}
            <div className="relative">
              <div className="relative rounded-3xl overflow-hidden aspect-[4/3] bg-[#0d3028]">
                <img
                  src="/images/tryon-demo.jpg"
                  alt="AI Virtual Try-On demonstration"
                  className="w-full h-full object-cover opacity-80"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center bg-[#171918]/60 backdrop-blur-sm rounded-2xl px-8 py-6">
                    <Sparkles size={32} className="text-[#D95E3F] mx-auto mb-3" />
                    <p className="text-white font-playfair text-xl">Discover → Try On → Shop</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* TRENDING */}
      {trendingProducts.length > 0 && (
        <section className="py-20 lg:py-28 bg-white px-4 sm:px-8">
          <div className="max-w-screen-xl mx-auto">
            <div className="flex items-end justify-between mb-12">
              <div>
                <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-3">On the Edit</p>
                <h2 className="font-playfair text-3xl lg:text-5xl text-[#171918]">Trending Now</h2>
              </div>
              <Link to="/trending" className="hidden sm:flex items-center gap-2 text-sm text-[#103C35] font-semibold hover:text-[#D95E3F] transition-colors">
                View All <ArrowRight size={16} />
              </Link>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {trendingProducts.map(product => (
                <ProductCard key={product.id} product={product} onTryOn={setTryOnProduct} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* COUPLE EDIT */}
      <section className="py-20 lg:py-28 bg-[#E9E1D4] px-4 sm:px-8">
        <div className="max-w-screen-xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-3">Couple Edit</p>
              <h2 className="font-playfair text-3xl lg:text-5xl text-[#171918] mb-6">
                Dress<br />Together
              </h2>
              <p className="text-[#AEB8A0] text-base leading-relaxed mb-8">
                Coordinated, complementary, and colour-story matched. Festive dressing for two — explore curated couple looks for every occasion.
              </p>
              <Link
                to="/couple"
                className="inline-flex items-center gap-2 px-8 py-3.5 bg-[#103C35] text-white font-semibold rounded-full hover:bg-[#0d3028] transition-colors"
              >
                EXPLORE COUPLE EDIT <ArrowRight size={16} />
              </Link>
            </div>
            <div>
              <img
                src="/images/couple-edit.jpg"
                alt="VIRAAS Couple Edit"
                className="w-full rounded-3xl object-cover aspect-[4/3]"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CURATED LOOKS */}
      <section className="py-20 lg:py-28 bg-[#F6F0E6] px-4 sm:px-8">
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-end justify-between mb-12">
            <div>
              <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-3">Curated Looks</p>
              <h2 className="font-playfair text-3xl lg:text-5xl text-[#171918]">Complete Looks</h2>
              <p className="text-[#AEB8A0] mt-2">Styled head to toe. One click to shop.</p>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredLooks.slice(0, 3).map(look => (
              <Link
                key={look.lookId}
                to={`/look/${look.lookId}`}
                className="group relative rounded-3xl overflow-hidden aspect-[3/4] bg-[#E9E1D4]"
              >
                <img
                  src={look.heroImage}
                  alt={look.title}
                  loading="lazy"
                  className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#171918]/90 via-[#171918]/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <p className="text-xs text-[#B7945A] font-semibold tracking-widest uppercase mb-2">{look.occasion}</p>
                  <h3 className="font-playfair text-2xl text-white mb-2">{look.title}</h3>
                  <p className="text-[#AEB8A0] text-sm line-clamp-2 mb-4">{look.description}</p>
                  <span className="inline-flex items-center gap-2 text-xs font-semibold text-white border border-white/30 px-4 py-2 rounded-full group-hover:bg-white group-hover:text-[#103C35] transition-colors">
                    VIEW LOOK <ArrowRight size={12} />
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ACCESSORIES */}
      {accessoryProducts.length > 0 && (
        <section className="py-20 lg:py-28 bg-white px-4 sm:px-8">
          <div className="max-w-screen-xl mx-auto">
            <div className="flex items-end justify-between mb-12">
              <div>
                <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-3">Complete the Look</p>
                <h2 className="font-playfair text-3xl lg:text-5xl text-[#171918]">Accessories</h2>
              </div>
              <Link to="/accessories" className="hidden sm:flex items-center gap-2 text-sm text-[#103C35] font-semibold hover:text-[#D95E3F] transition-colors">
                View All <ArrowRight size={16} />
              </Link>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {accessoryProducts.map(product => (
                <ProductCard key={product.id} product={product} onTryOn={setTryOnProduct} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* BUDGET COLLECTIONS */}
      <section className="py-20 lg:py-28 bg-[#F6F0E6] px-4 sm:px-8">
        <div className="max-w-screen-xl mx-auto">
          <div className="mb-12">
            <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-3">For Every Budget</p>
            <h2 className="font-playfair text-3xl lg:text-5xl text-[#171918]">Shop Your Budget</h2>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { label: 'Under ₹999', href: '/women?budget=under-999', bg: 'bg-[#E9E1D4]' },
              { label: 'Under ₹1,499', href: '/women?budget=under-1499', bg: 'bg-[#AEB8A0]/30' },
              { label: 'Under ₹1,999', href: '/women?budget=under-1999', bg: 'bg-[#103C35]/10' },
              { label: '₹2,999+', href: '/women?budget=premium', bg: 'bg-[#D95E3F]/10' },
            ].map(b => (
              <Link
                key={b.label}
                to={b.href}
                className={`${b.bg} rounded-2xl p-8 flex flex-col items-center justify-center text-center hover:shadow-md transition-all group aspect-square`}
              >
                <p className="font-playfair text-xl lg:text-2xl text-[#171918] mb-2 group-hover:text-[#103C35] transition-colors">{b.label}</p>
                <span className="text-xs text-[#AEB8A0] flex items-center gap-1 group-hover:text-[#D95E3F] transition-colors">
                  Explore <ArrowRight size={12} />
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* JOURNAL */}
      <section className="py-20 lg:py-28 bg-white px-4 sm:px-8">
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-end justify-between mb-12">
            <div>
              <p className="text-xs font-semibold tracking-[0.3em] text-[#B7945A] uppercase mb-3">The Journal</p>
              <h2 className="font-playfair text-3xl lg:text-5xl text-[#171918]">Style Stories</h2>
            </div>
            <Link to="/journal" className="hidden sm:flex items-center gap-2 text-sm text-[#103C35] font-semibold hover:text-[#D95E3F] transition-colors">
              All Articles <ArrowRight size={16} />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {articles.slice(0, 4).map(article => (
              <Link
                key={article.id}
                to={`/journal/${article.slug}`}
                className="group"
              >
                <div className="relative aspect-[4/3] rounded-2xl overflow-hidden bg-[#E9E1D4] mb-4">
                  <img
                    src={article.image}
                    alt={article.title}
                    loading="lazy"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <p className="text-xs text-[#B7945A] font-semibold uppercase tracking-widest mb-2">{article.category}</p>
                <h3 className="text-sm font-medium text-[#171918] leading-snug group-hover:text-[#103C35] transition-colors line-clamp-2 mb-2">
                  {article.title}
                </h3>
                <p className="text-xs text-[#AEB8A0]">{article.readTime} read</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* WHATSAPP */}
      <section className="py-16 bg-[#103C35] px-4 sm:px-8">
        <div className="max-w-screen-xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
          <div>
            <h3 className="font-playfair text-2xl lg:text-3xl text-white mb-2">
              Need help finding a look?
            </h3>
            <p className="text-[#AEB8A0] text-sm">Our team is just a message away.</p>
          </div>
          <a
            href={`https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_MESSAGE}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-shrink-0 flex items-center gap-3 px-8 py-4 bg-[#25D366] text-white font-semibold rounded-full hover:bg-[#1fba58] transition-colors"
          >
            <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
            </svg>
            CHAT WITH VIRAAS
          </a>
        </div>
      </section>

      {/* TryOn Modal */}
      {tryOnProduct && (
        <TryOnModal product={tryOnProduct} onClose={() => setTryOnProduct(null)} />
      )}
    </>
  );
}
