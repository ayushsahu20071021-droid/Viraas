import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, Sparkles, ShoppingBag } from 'lucide-react';
import { type Product } from '../data/products';
import { toggleSavedLook, isLookSaved } from '../utils/savedLooks';
import { trackAffiliateClick, trackEvent } from '../utils/analytics';

interface Props {
  product: Product;
  onTryOn?: (product: Product) => void;
}

const merchantColors: Record<string, string> = {
  MYNTRA: 'bg-[#FF3F6C]/10 text-[#FF3F6C]',
  AJIO: 'bg-[#F26522]/10 text-[#F26522]',
  FLIPKART: 'bg-[#2874F0]/10 text-[#2874F0]',
  SHOPSY: 'bg-[#2874F0]/10 text-[#2874F0]',
  MEESHO: 'bg-[#9C27B0]/10 text-[#9C27B0]',
  NYKAA: 'bg-[#FC2779]/10 text-[#FC2779]',
};

export default function ProductCard({ product, onTryOn }: Props) {
  const [saved, setSaved] = useState(() => isLookSaved(product.id));
  const [imgError, setImgError] = useState(false);

  const handleSave = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const isNowSaved = toggleSavedLook(product.id);
    setSaved(isNowSaved);
    if (isNowSaved) trackEvent('save_look', { productId: product.id });
  };

  const handleShop = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const url = product.affiliateUrl || product.merchantUrl;
    if (url && url !== '#') {
      trackAffiliateClick(product.id, product.merchant, product.category);
      window.open(url, '_blank', 'noopener,noreferrer');
    }
  };

  const handleTryOn = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (onTryOn) onTryOn(product);
    trackEvent('click_try_on', { productId: product.id });
  };

  const discount = product.discount > 0 ? `${product.discount}% off` : null;

  return (
    <Link
      to={`/product/${product.id}`}
      className="group block bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300"
      onClick={() => trackEvent('view_product', { productId: product.id, category: product.category })}
    >
      {/* Image */}
      <div className="relative aspect-[3/4] overflow-hidden bg-[#E9E1D4]">
        <img
          src={imgError ? '/images/hero-women.jpg' : product.imageUrl}
          alt={product.title}
          loading="lazy"
          onError={() => setImgError(true)}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />

        {/* Discount badge */}
        {discount && (
          <span className="absolute top-3 left-3 px-2 py-1 bg-[#D95E3F] text-white text-xs font-semibold rounded-full">
            {discount}
          </span>
        )}

        {/* Save */}
        <button
          onClick={handleSave}
          className={`absolute top-3 right-3 w-9 h-9 flex items-center justify-center rounded-full shadow-md transition-all ${
            saved ? 'bg-[#D95E3F] text-white' : 'bg-white/90 text-[#171918] hover:bg-[#D95E3F] hover:text-white'
          }`}
          aria-label={saved ? 'Remove from saved' : 'Save look'}
        >
          <Heart size={16} fill={saved ? 'currentColor' : 'none'} />
        </button>

        {/* Hover Actions */}
        <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-[#171918]/70 to-transparent translate-y-full group-hover:translate-y-0 transition-transform duration-300">
          <div className="flex gap-2">
            {product.tryOnEnabled && (
              <button
                onClick={handleTryOn}
                className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-[#F6F0E6] text-[#103C35] text-xs font-semibold rounded-full hover:bg-white transition-colors"
              >
                <Sparkles size={13} />
                TRY ON
              </button>
            )}
            <button
              onClick={handleShop}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-[#D95E3F] text-white text-xs font-semibold rounded-full hover:bg-[#c24e31] transition-colors"
            >
              <ShoppingBag size={13} />
              SHOP
            </button>
          </div>
        </div>
      </div>

      {/* Info */}
      <div className="p-4">
        <div className="flex items-start justify-between gap-2 mb-1.5">
          <h3 className="text-sm font-medium text-[#171918] leading-snug line-clamp-2 flex-1">
            {product.title}
          </h3>
          <span className={`text-xs px-2 py-0.5 rounded-full font-medium flex-shrink-0 ${merchantColors[product.merchant] || 'bg-gray-100 text-gray-500'}`}>
            {product.merchant.charAt(0) + product.merchant.slice(1).toLowerCase()}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-base font-bold text-[#103C35]">₹{product.price.toLocaleString('en-IN')}</span>
          {product.mrp > product.price && (
            <span className="text-xs text-[#AEB8A0] line-through">₹{product.mrp.toLocaleString('en-IN')}</span>
          )}
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-1 mt-2">
          {product.styleTags.slice(0, 2).map(tag => (
            <span key={tag} className="text-xs text-[#AEB8A0] bg-[#F6F0E6] px-2 py-0.5 rounded-full">{tag}</span>
          ))}
        </div>
      </div>
    </Link>
  );
}
